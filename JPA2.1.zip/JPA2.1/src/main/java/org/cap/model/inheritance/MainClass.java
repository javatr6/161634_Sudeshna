package org.cap.model.inheritance;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.cap.model.manytomany.Events;

public class MainClass {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager =emf.createEntityManager();
		EntityTransaction transaction = entityManager.getTransaction();
		
		transaction.begin();
		
		
		Project project = new Project(1111,"ICICI");
		project.setDateOfProject(LocalDate.now());
		
		 Module module = new Module("Java",LocalDate.now());
		 
		 module.setProjectId(222);
		 module.setProjectName("Citi Bank");
		
		 
		 Task task  = new Task();
		 task.setModuleName("Login");
		 task.setProjectId(333);
		 task.setProjectName("AXIS");
		 task.setTaskName("Transaction");
		 
		 entityManager.persist(project);
		 entityManager.persist(module);
		 entityManager.persist(task);
		 
		 
		 transaction.commit();
		 entityManager.close();
		  
	}

}
