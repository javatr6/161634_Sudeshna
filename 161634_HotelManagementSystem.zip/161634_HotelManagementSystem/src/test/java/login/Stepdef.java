package login;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdef {
	private WebDriver driver;
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\chromedriver.exe");
		driver=new ChromeDriver();
	}
	
	@Given("^open login page$")
	public void open_login_page() throws Throwable {
		driver.get("http://localhost:8082/HotelManagementSystem/index.html");
		String head = driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/h1")).getText();
		assertEquals("Hotel Booking Application",head);
	}
	
	@Given("^username and password$")
	public void username_and_password() throws Throwable {
		driver.findElement(By.name("userName")).sendKeys("capgemini");
		driver.findElement(By.name("userPwd")).sendKeys("capg1234");
	}

	@When("^login validate details$")
	public void login_validate_details() throws Throwable {
		WebElement login=driver.findElement(By.name("login"));
		login.submit();
	}

	@Then("^redirect to hotelbooking page$")
	public void redirect_to_hotelbooking_page() throws Throwable {
		driver.navigate().to("http://localhost:8082/HotelManagementSystem/pages/hotelbooking.html");
	}

	@And("^username$")
	public void username() throws Throwable {
		driver.findElement(By.name("userName")).sendKeys("");
		Thread.sleep(1000);
	}

	@When("^login$")
	public void login() throws Throwable {
		WebElement login=driver.findElement(By.name("login"));
		login.click();
		Thread.sleep(1000);
	}
	
	@Then("^show errormessage$")
	public void show_errormessage() throws Throwable {
		String userErrorMsg=driver.findElement(By.xpath("//*[@id=\"userErrMsg\"]")).getText();
		System.out.println("Msg"+userErrorMsg);
		assertEquals("* Please enter userName.",userErrorMsg);
		Thread.sleep(1000);
		
	}


	

	@And("^password$")
	public void password() throws Throwable {
		driver.findElement(By.name("userName")).sendKeys("capgemini");
		driver.findElement(By.name("userPwd")).sendKeys("");
		Thread.sleep(1000);
	}
	@When("^login clicked$")
	public void login_clicked () throws Throwable {
		WebElement login=driver.findElement(By.name("login"));
		login.click();
		Thread.sleep(1000);
	}
	
	@Then("^show popup$")
	public void show_popup() throws Throwable {
		String userErrorMsg=driver.findElement(By.xpath("//*[@id=\"pwdErrMsg\"]")).getText();
		System.out.println("Msg"+userErrorMsg);
		assertEquals("* Please enter password.",userErrorMsg);
	}

	
	@After
	public void tearDown() {
		driver.quit();
	}
}
