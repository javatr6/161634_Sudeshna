package org.cap.bean;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import javax.persistence.Table;
@Table(name="transaction")
@Entity
public class TransactionBean {
	@Id
	@GeneratedValue
	private Integer transactionid;

	@ManyToOne
	@JoinColumn(name="Route_Id")
	private RouteMapBean route;
	

	
	private String empId;
	private LocalDate transactiondate;
	private Double totalkm;
	private Integer monthlyfare;
	
	
	public TransactionBean() {
		super();
	}
	public TransactionBean(RouteMapBean route,String empId,
			LocalDate transactiondate, Double totalkm, Integer monthlyfare) {
		super();
	
		this.route = route;
	
		this.empId = empId;
		this.transactiondate = transactiondate;
		this.totalkm = totalkm;
		this.monthlyfare = monthlyfare;
	}


	public TransactionBean(String empId, LocalDate transactiondate, Double totalkm,
			Integer monthlyfare) {
		super();
		
		this.empId = empId;
		this.transactiondate = transactiondate;
		this.totalkm = totalkm;
		this.monthlyfare = monthlyfare;
	}
	
	
	public TransactionBean(Integer transactionid,String empId, LocalDate transactiondate,
			Double totalkm, Integer monthlyfare) {
		super();
		this.transactionid = transactionid;
	
		this.empId = empId;
		this.transactiondate = transactiondate;
		this.totalkm = totalkm;
		this.monthlyfare = monthlyfare;
	}


	public Integer getTransactionid() {
		return transactionid;
	}


	public void setTransactionid(Integer transactionid) {
		this.transactionid = transactionid;
	}




	public String getEmpId() {
		return empId;
	}


	public void setEmpId(String empId) {
		this.empId = empId;
	}


	public LocalDate getTransactiondate() {
		return transactiondate;
	}


	public void setTransaction_date(LocalDate transactiondate) {
		this.transactiondate = transactiondate;
	}


	public Double getTotalkm() {
		return totalkm;
	}


	public void setTotalkm(Double totalkm) {
		this.totalkm = totalkm;
	}


	public Integer getMonthlyfare() {
		return monthlyfare;
	}


	public void setMonthly_fare(Integer monthlyfare) {
		this.monthlyfare = monthlyfare;
	}
	@Override
	public String toString() {
		return "TransactionBean [transactionid=" + transactionid + ", route=" + route + ", empId=" + empId
				+ ", transactiondate=" + transactiondate + ", totalkm=" + totalkm + ", monthlyfare=" + monthlyfare
				+ "]";
	}

}