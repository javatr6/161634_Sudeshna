package org.cap.bean;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;



public class Tester {

	public static void main(String[] args) {
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		BusBean jill=new BusBean("161634","Sudeshna","Nelapatla","Female","Chennai",
				LocalDate.of(2017, 10,11),"sud@gmail.com","Chennai SIPCOT","Chennai MIPL","Tambaram",
				LocalTime.of(9,47),"Pending");
		
		LoginBean login=new LoginBean("sud","sud123");
		
		RouteMapBean route=new RouteMapBean(01,"ChennaiMIPL,Tambaram",10,60,"TN7398","Jack",30);
		
		RouteMapBean route1= new RouteMapBean(02,jill,"ChennaiMIPL,Tambaram",5,
			60,"TN1234","sri",30);
		jill.setRoute(route1);
		TransactionBean transactions=new TransactionBean(route,"161625", LocalDate.of(2018,10,17),45.00,7000);
		entityManager.persist(jill);
		entityManager.persist(login);
		entityManager.persist(route);
		entityManager.persist(route1);
		entityManager.persist(transactions);
		transaction.commit();
		entityManager.close();

	}

} 

