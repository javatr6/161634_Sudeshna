package org.cap.bean;



import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
@Table(name="login")
@Entity



public class LoginBean {
	@Id
	@GeneratedValue
	private Integer id;
	private String userName;
	private String passWord;
	public LoginBean() {
		super();
	}
	public LoginBean(String userName, String passWord) {
		super();
		this.userName = userName;
		this.passWord = passWord;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassWord() {
		return passWord;
	}
	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}
	@Override
	public String toString() {
		return "LoginBean [userName=" + userName + ", passWord=" + passWord + "]";
	}
	

} 
 
