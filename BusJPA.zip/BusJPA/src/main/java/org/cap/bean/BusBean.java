package org.cap.bean;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Table(name="buspassrequest")
@Entity
public class BusBean {
	@Id
	@GeneratedValue
	private Integer reqId;
	private String empId;
	private String firstName;
	private String lastName;
	private String gender;
	private String addr;
	private LocalDate dateofjoining;
	private String emailId;
	private String location;
	private String pickupLocation;
	private String designation;
	private LocalTime pickupTime;
	
	private String status="Pending";
	@OneToOne
	@JoinColumn
	private RouteMapBean route;
	
	
	public BusBean() {
		super();
	}
	
	
	
	
	public BusBean(String empId, String firstName, String lastName, String gender, String addr,
			LocalDate dateofjoining, String emailId, String location, String pickupLocation, String designation,
			LocalTime pickupTime, String status) {
		super();
		this.empId = empId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.addr = addr;
		this.dateofjoining = dateofjoining;
		this.emailId = emailId;
		this.location = location;
		this.pickupLocation = pickupLocation;
		this.designation = designation;
		this.pickupTime = pickupTime;
		this.status = status;
	}




	public BusBean(String empId, String firstName, String lastName, String gender, String addr,
			LocalDate dateofjoining, String emailId, String location, String pickupLocation, String designation,
			LocalTime pickupTime, String status, Integer reqId) {
		super();
		this.empId = empId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.addr = addr;
		this.dateofjoining = dateofjoining;
		this.emailId = emailId;
		this.location = location;
		this.pickupLocation = pickupLocation;
		this.designation = designation;
		this.pickupTime = pickupTime;
		this.status = status;
		this.reqId = reqId;
	}



	public String getStatus() {
		return status;
	}



	public void setStatus(String status) {
		this.status = status;
	}



	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public LocalDate getDateofjoining() {
		return dateofjoining;
	}
	public void setDateofjoining(LocalDate dateofjoining) {
		this.dateofjoining = dateofjoining;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getPickupLocation() {
		return pickupLocation;
	}
	public void setPickupLocation(String pickupLocation) {
		this.pickupLocation = pickupLocation;
	}
	public LocalTime getPickupTime() {
		return pickupTime;
	}
	public void setPickupTime(LocalTime pickupTime) {
		this.pickupTime = pickupTime;
	}
	public Integer getReqId() {
		return reqId;
	}
	public void setReqId(Integer reqId) {
		this.reqId = reqId;
	}



	public RouteMapBean getRoute() {
		return route;
	}




	public void setRoute(RouteMapBean route) {
		this.route = route;
	}




	@Override
	public String toString() {
		return "BusBean [empId=" + empId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", gender=" + gender + ", addr=" + addr + ", dateofjoining=" + dateofjoining + ", emailId=" + emailId
				+ ", location=" + location + ", pickupLocation=" + pickupLocation + ", designation=" + designation
				+ ", pickupTime=" + pickupTime + ", status=" + status + ", reqId=" + reqId + "]";
	}
	
	

} 
 

