package com.capgemini.service;

import com.capgemini.model.LoginBean;

public interface ILoginService {
	public abstract boolean checkUser(LoginBean loginBean);
}
